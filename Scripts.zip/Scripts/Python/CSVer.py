import numpy as np
import pandas as pd
import os

# Define the directory and file name
new_directory = ""
file_name = "A_1.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)



file_name = "A_2.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)

file_name = "A_3.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)

file_name = "A_5.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)

# Define the directory and file name
new_directory = ""
file_name = "Z_t_1.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)



file_name = "Z_t_2.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)

file_name = "Z_t_3.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)

file_name = "Z_t_5.npy"  # Replace with your actual file name

# Construct the full file path for the .npy file
file_path = os.path.join(new_directory, file_name)

# Load the numpy file
data = np.load(file_path)

# Convert the numpy array to a pandas DataFrame
df = pd.DataFrame(data)

# Construct the full file path for the .csv file
csv_file_path = os.path.join(new_directory, file_name.replace('.npy', '.csv'))

# Save the DataFrame as a CSV file
df.to_csv(csv_file_path, index=False, header=False)


