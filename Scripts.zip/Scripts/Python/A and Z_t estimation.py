
"""
This script is used for the historicsl matrix A and the stohastic process Z_t.
The script will be run with variouse dimensions for A and Z_t, thus increaseing the 
fit and reducing the loss (thoretically).
"""

# %% Importing of libraries

import numpy as np

from keras.layers import Input, Dense, Lambda, Reshape, Dot
 ## libraries ## 
import pandas as pd
import numpy as np
# import scipy
from keras.layers import Input, Dense, Lambda, Reshape, Dot
from keras.optimizers import Adam
from keras.models import Model
import tensorflow as tf
import matplotlib.pyplot as plt
import os

# %% Data Loading

 # p_target = pd.read_csv(Prices(without_mean).csv", header=None, dtype=float) # import price file
p_target = p_target.transpose()
p_target = p_target.values
p_target = p_target.reshape(p_target.shape[0], p_target.shape[1], 1)
p_target = tf.convert_to_tensor(p_target, dtype=tf.float32)

# x_train = pd.read_csv("ttm.csv",header=None, dtype=float) # import time to maturity file
x_train = tf.convert_to_tensor(x_train)

numbers = [1,2,3, 5, 7]

for i in numbers:
    n = i
    

    M = p_target.shape[0]  # Number of maturities
    N = p_target.shape[1]  # Number of observation dates # Number of observation dates

# %% Optimization Functinons

    def build_scalarmodel(n):
        x_In = Input((1,))
        z_In = Input((n,))
        ## build x*A, i.e. input x times a 1 times n^2 matrix
        A_vec = Dense(n**2, use_bias=False)(x_In)
        ## reorder the matrix x*A to an n times n matrix
        A = Reshape((n, n))(A_vec)
        ## Calculate the matrix exponential exp(x*A)
        exp_xA = Lambda(lambda x: tf.linalg.expm(x))(A)
        all_ones = Lambda(lambda x: tf.ones((n,)))(x_In)
        
        e_exp_xA = tf.linalg.matvec(exp_xA, all_ones)
        
        p = Dot(1)([e_exp_xA, z_In])
        
        return Model(inputs=[x_In, z_In], outputs=p)

    ## Build the model
    pricemodel = build_scalarmodel(n)
    ## Overview of the model
    pricemodel.summary()
    
    #### Defines the model
    ## Inputs: x, z
    ## Outputs [g(x_1,z), ... , g(x_M,z)] where g(x,z) is the pricemodel from before
    ## x = x_1, .., x_M are the maturities
    ## z = z_1, .., z_n are the model states
    def build_vectormodel(pricemodel): 
        x_In = Input((M,)) 
        z_In = Input((n,))
        p = []
        for i in range(M): 
            p = p + [pricemodel([x_In[:, i], z_In])]
        return Model(inputs=[x_In, z_In], outputs=p)
    
    pricevec = build_vectormodel(pricemodel)
    ## Uncomment next line if your like to see the model structure
    # pricevec.summary()
    
    
    #### Training the model on the data
    # Initialize a trainable variable for z
    z_trainable =  tf.Variable(tf.fill((N, n), 0.0)) #  tf.Variable(tf.random.normal(mean=-7, stddev=3.5, shape=(N, n))) initalize with some number
    # Combine x and z as input to the model
    input_data = [x_train, z_trainable] 
    # Define the mean squared error loss function
    def loss_function(y_true, y_pred):
        return tf.keras.losses.mean_squared_error(y_true, y_pred)
    
    # Define the optimizer
    optimizer = Adam(learning_rate=0.1) 
    
    # Use TensorFlow GradientTape to compute gradients
    def compute_gradients(input_vars):
        x, z = input_vars
        with tf.GradientTape() as tape:
            p_pred = pricevec([x, z])
            loss = loss_function(p_target, p_pred)
            gradients = tape.gradient(loss, pricevec.trainable_variables + [z])
        return gradients
    
    # Function for training loop using gradient descent
    def update_z_weights(epochs=100, silent=True):
        br_step = 10
        br = br_step
        for epoch in range(epochs):
            if silent == False:
                print(epoch, "/", epochs, "...", end="")
            if epoch >= br:
                br = br + br_step
                print("")
            gradients = compute_gradients([x_train, z_trainable])
            optimizer.apply_gradients(zip(gradients, pricevec.trainable_variables + [z_trainable]))
            # Update only the model's trainable variables
            z_trainable.assign(z_trainable[:, 0:])
    
    def train(epochs=50, maxLoss=0.001, tries=20, verbose=1):
        ## Improve weights in case of bad loss
        silent = True
        if verbose == 1:
            silent = False
        if verbose != 0:
            print("Attempting to reach a loss of at most", maxLoss, "with", epochs, "(adaptive) gradient descent steps.\nIf loss is not reached. Repeat up to", tries, "times.")
        for k in range(tries):
            Loss = np.mean(loss_function(p_target, pricevec([x_train, z_trainable])))  # MSE
            if verbose != 0:
                print("(MSE) Loss after", k, "attempt(s):", Loss, "\n")
            if Loss > maxLoss:
                if verbose != 0:
                    print("Updating parameters with another", epochs, "gradient descent steps!")
                update_z_weights(epochs, silent)
            if Loss <= maxLoss:
                break
        ## Obtain the optimized values
        optimized_weights = [var.numpy() for var in pricemodel.trainable_variables]
        optimized_z = z_trainable.numpy()
        return optimized_weights, optimized_z
    
    

# %% Saving output and optimization

    print("optimization for:", n, "dimensions", "\n")
    
## Start parameter optimisation

    optimized_weights, optimized_z = train(epochs=100, maxLoss=0.00001, tries=50, verbose=1)

    new_directory = ""
    os.chdir(new_directory)

    A = np.array(optimized_weights).reshape(n, n)
    Z_t = optimized_z

    file_1 = "A_" + str(n) +".npy"
    file_2 = "Z_t_" + str(n) +".npy"

    np.save(file_1, A)
    np.save(file_2, Z_t)

