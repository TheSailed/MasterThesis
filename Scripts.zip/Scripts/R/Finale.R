## Packages ----

library(reticulate)
library(Matrix)
library(yuima)
library(zoo)
library(expm)
library(mvtnorm)
library(mvnormtest)
library(MVN)

## loading data and setting seed----

set.seed(123)

#setwd() #where the data is

ttm <- readRDS("ttm.rds")
settlement <- readRDS("settlement.rds")

settlement <- settlement[as.Date(settlement$date) < as.Date("2024-01-01"),]
ttm <- ttm[as.Date(ttm$date) < as.Date("2024-01-01"),]

time <- ttm[,-1]/365
p <- settlement[,-1]

x <- c(na.omit(ttm$CLJ2024))/365
f_t <- c(na.omit(settlement$CLJ2024))
dates <- as.Date(c(ttm$date[!is.na(settlement$CLJ2024)]))

c_t <- mean(settlement[,-1] |> as.matrix(), na.rm = T)

#setwd() # where python data is

## Plotting of term structure data ----

row.sample <- sample(9000:nrow(settlement),4)

dates.of.plot <- settlement[row.sample,1]

termstructures.p <- settlement[row.sample,-1] |> as.matrix() |> unname()

termstructures.t <- ttm[row.sample,-1] |> as.matrix() |> unname()

ordering <- order(c(termstructures.t[1,] |> na.omit()), decreasing = FALSE)

plot(c(termstructures.t[1,] |> na.omit())[ordering], c(termstructures.p[1,] |> na.omit())[ordering],
     col = 1, type = "l",
     xlab = "Days until maturity", ylab = "Settlement price", ylim = c(50,66), lwd = 2)

points(c(termstructures.t[1,] |> na.omit())[ordering], c(termstructures.p[1,] |> na.omit())[ordering],
       col = 1, pch = 16)

# Plot the other rows
for (i in 2:nrow(termstructures.p)) {
  ordering <- order(c(termstructures.t[i,] |> na.omit()), decreasing = FALSE)
  lines(c(termstructures.t[i,] |> na.omit())[ordering], c(termstructures.p[i,] |> na.omit())[ordering],, col = i, lwd = 2)
  points(c(termstructures.t[i,] |> na.omit())[ordering], c(termstructures.p[i,] |> na.omit())[ordering],, col = i, pch = 16)
}
legend("topright", legend = dates.of.plot, col = 1:nrow(termstructures.p), lty = 1, lwd = 3)

## 1 dim ---- 

## Loading estimated A and Z_t for 1 dim and plotting Z_t

A_1 <- read.csv("A_1.csv", header = FALSE) |> unname() |> as.matrix()

Z_t_1 <- read.csv("Z_t_1.csv", header = FALSE) |> unname() |> as.matrix()

matplot(ttm$date ,Z_t_1, type = "l", lty = 1, col = 1:ncol(Z_t_1), xlab = "Time", ylab = "Values", lwd = 2)

### selection of one specific year

Z_t_1 <- Z_t_1[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                 as.Date(settlement$date) < as.Date("2023-01-01"),] |> as.matrix()

matplot(as.Date(settlement$date[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
           as.Date(settlement$date) < as.Date("2023-01-01")]), Z_t_1, type = "l", lty = 1, col = 1:ncol(Z_t_1), xlab = "Time", ylab = "Values", lwd = 2)

## base curves and plotting

g_1 <-  sapply(x, function(y) (rep(1,dim(A_1)[1]) %*% expm(y * A_1 )) %*% c(1,rep(1,dim(A_1)[1]-1)))

plot(x*365, g_1, type = "l", col = "blue", lwd = 2, ylab = "Values", xlab = "Days until maturuty")

## mu, mean reversion and sigma estimation for Z_t as an OU process

### Yuima package

sol <- c("x1")  # Single stochastic variable

a <- c("lambda1 * (mu1 - x1)") # drift

b <- matrix(c("sigma11"), 1, 1) # diffusion

ymodel <- setModel(drift = a, diffusion = b, state.variable = sol,
                   solve.variable = sol, time.variable = "t")

Z_t <- setYuima(model = ymodel, data = setData(Z_t_1)) # setting the model

qmle1 <- qmle(Z_t, start = list(lambda1 = 0, mu1 = mean(Z_t_1), sigma11 = sd(Z_t_1)), 
             lower = list(lambda1 = -100, mu1 = -100, sigma11 = -100), 
             upper = list(lambda1 = 100, mu1 = 100, sigma11 = 100),
             method = "L-BFGS-B")

summary(qmle1)

q_sigma_1 <- coef(qmle1)[1] |> unname()
q_lambda_1 <- coef(qmle1)[2] |> unname()
q_mu_1 <- coef(qmle1)[3] |> unname()

## checking if OU fits well

hist(1/q_sigma_1 * (diff(Z_t_1) - q_lambda_1 * (q_mu_1 - Z_t_1[1:259])), main = "", xlab = "")

## 2 dim ----

## Loading estimated A and Z_t for 1 dim and plotting Z_t

A_2 <- read.csv("A_2.csv", header = FALSE) |> unname() |> as.matrix()

Z_t_2 <- read.csv("Z_t_2.csv", header = FALSE) |> unname() |> as.matrix()

matplot(ttm$date,Z_t_2, type = "l", lty = 1, col = 1:ncol(Z_t_2), xlab = "Time", ylab = "Values", lwd = 2)

### selection of one specific year

Z_t_2 <- Z_t_2[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                 as.Date(settlement$date) < as.Date("2023-01-01"),]

matplot(as.Date(settlement$date[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                                  as.Date(settlement$date) < as.Date("2023-01-01")]),Z_t_2, type = "l", lty = 1, col = 1:ncol(Z_t_2), xlab = "Time", ylab = "Values", lwd = 2)

## base curves and plotting

g_1 <-  sapply(x, function(y) (c(1,1) %*% expm(y * A_2 )) %*% c(1,0))
g_2 <-  sapply(x, function(y) (c(1,1) %*% expm(y * A_2 )) %*% c(0,1))

plot(x*365, g_1, type = "l", col = "blue", lwd = 2, ylab = "Values", xlab = "Days until maturuty",ylim = c(0.8, 1.5))
lines(x*365, g_2, type = "l", col = "red", lwd = 2)
legend("topright", legend = c("g_1", "g_2"), col = c("blue", "red"), lwd = 2)

## mu, mean reversion and sigma estimation for Z_t as an OU process

### Yuima package

sol <- c("x1", "x2")

a <- c("lambda1 * (mu1 - x1) + colambda2 * (mu2 - x2)", 
       "lambda2 * (mu2 - x2) + colambda1 * (mu1 - x1)") # drift vector

b <- matrix(c("sigma11", "sigma12",
              "sigma21", "sigma22"), 2, 2, byrow = T) # diffusion matrix

ymodel <- setModel(drift = a, diffusion = b, state.variable = sol,
                   solve.variable = sol, time.variable = "t") 

Z_t <- setYuima(model = ymodel, data = setData(Z_t_2)) # setting the model

qmle2 <- qmle(Z_t, start = list(lambda1 = 0, lambda2 = 0,
                               mu1 = colMeans(Z_t_2)[1], mu2 = colMeans(Z_t_2)[2],
                               colambda1 = 0, colambda2 = 0,
                               sigma11 = cov(Z_t_2)[1,1], sigma12 = cov(Z_t_2)[1,2],
                               sigma21 = cov(Z_t_2)[2,1], sigma22 = cov(Z_t_2)[2,2]), 
             lower = list(lambda1 = -100, lambda2 = -100,
                          colambda1 = -100, colambda2 = -100,
                          mu1 = -100, mu2 = -100,
                          sigma11 = -100, sigma12 = -100,
                          sigma21 = -100, sigma22 = -100), 
             upper = list(lambda1 = 100, lambda2 = 100,
                          colambda1 = 100, colambda2 = 100,
                          mu1 = 100, mu2 = 100,
                          sigma11 = 100, sigma12 = 100,
                          sigma21 = 100, sigma22 = 100),
             method = "L-BFGS-B")

summary(qmle2)

q_sigma_2 <- matrix(c(coef(qmle2)[1:4] |> unname()),nrow = 2,ncol = 2, byrow = T)
q_lambda_2 <- matrix(c(coef(qmle2)[c(5,7,10,9)] |> unname()),nrow = 2,ncol = 2, byrow = T)
q_mu_2 <- coef(qmle2)[c(6,8)] |> unname()

## checking if OU fits well

err_2 <- matrix(nrow = 259, ncol = 2)

for (i in 1:259) {
  
  err_2[i,] <- c(solve(q_sigma_2) %*% (diff(Z_t_2)[i,] - q_lambda_2 %*% (q_mu_2 - Z_t_2[i,])))
  
}

par(mfrow = c(2, 1))

hist(err_2[,1], xlab = "", main = "First component")
hist(err_2[,2],  xlab = "", main = "Second component")


par(mfrow = c(1, 1))
## base curves with eigen values

eigen(A_2)

sig_2 <- q_sigma_2 %*% t(q_sigma_2)

eigens_2 <- eigen(sig_2)

eigens_2

h_1 <-  sapply(x, function(y) (c(1,1) %*% expm(y * A_2 )) %*% eigens_2$vectors[,1])
h_2 <-  sapply(x, function(y) (c(1,1) %*% expm(y * A_2 )) %*% eigens_2$vectors[,2])
par(mfrow =c(1,1))
plot(x*365, h_1, type = "l", col = "blue", lwd = 2, ylab = "Values", xlab = "Days until maturuty",ylim = c(-2,0))
lines(x*365, h_2, type = "l", col = "red", lwd = 2)

legend("topright", legend = c("h_1", "h_2"), col = c("blue", "red"), lwd = 2)

## 3 dim ----

## Loading estimated A and Z_t for 1 dim and plotting Z_t

A_3 <- read.csv("A_3.csv", header = FALSE) |> unname() |> as.matrix()

Z_t_3 <- read.csv("Z_t_3.csv", header = FALSE) |> unname() |> as.matrix()

matplot(ttm$date, Z_t_3, type = "l", lty = 1, col = 1:ncol(Z_t_3), xlab = "Time", ylab = "Values", lwd = 2)

### selection of one specific year

Z_t_3 <- Z_t_3[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                 as.Date(settlement$date) < as.Date("2023-01-01"),]

matplot(as.Date(settlement$date[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                                  as.Date(settlement$date) < as.Date("2023-01-01")]),Z_t_3, type = "l", lty = 1, col = 1:ncol(Z_t_3), xlab = "Time", ylab = "Values", lwd = 2)

## base curves and plotting

g_1 <-  sapply(x, function(y) (c(1,1,1) %*% expm(y * A_3 )) %*% c(1,0,0))
g_2 <-  sapply(x, function(y) (c(1,1,1) %*% expm(y * A_3 )) %*% c(0,1,0))
g_3 <-  sapply(x, function(y) (c(1,1,1) %*% expm(y * A_3 )) %*% c(0,0,1))

plot(x*365, g_1, type = "l", col = "blue", lwd = 2, ylab = "Values", xlab = "Days until maturuty",ylim = c(0, 3))
lines(x*365, g_2, type = "l", col = "red", lwd = 2)
lines(x*365, g_3, type = "l", col = "green", lwd = 2)
legend("topright", legend = c("g_1", "g_2","g_3"), col = c("blue", "red","green"), lwd = 2)

## mu, mean reversion and sigma estimation for Z_t as an OU process

delta_t <- 1
X <- Z_t_3

log_likelihood <- function(params, X, delta_t) {
  mu <- params[1:3]
  A <- matrix(params[4:12], nrow = 3,ncol = 3, byrow = T)
  Simga <- matrix(params[13:21], 3, 3, byrow = T)
  
  
  # Compute Sigma from the Cholesky factor
  Sigma <- Simga %*% t(Simga)
  
  n <- nrow(X)
  logL <- 0
  
  for (i in 2:n) {
    mu_t <- X[i-1, ] + A %*% (mu - X[i-1, ]) * delta_t
    Sigma_t <- Sigma * delta_t
    
    logL <- logL + dmvnorm(X[i, ], mean = mu_t, sigma = Sigma_t, log = TRUE)
  }
  
  return(-logL) # Negative log-likelihood
}


# Initial parameter guesses
initial_params <- c(colMeans(Z_t_3), rep(0,9), c(sqrt(cov(Z_t_3))))

# Use optim to maximize the log-likelihood
result_3 <- optim(initial_params, log_likelihood, X = X, delta_t = delta_t, method = "BFGS", hessian = TRUE)

q_sigma_3 <- matrix(result_3$par[13:21], nrow = 3,ncol = 3, byrow = T)
q_lambda_3 <- matrix(result_3$par[4:12], nrow = 3,ncol = 3, byrow = T)
q_mu_3 <- result_3$par[1:3]

# Compute the standard errors from the Hessian
hessian_inv <- solve(result_3$hessian)
standard_errors <- sqrt(diag(hessian_inv))

# Extract standard errors for each parameter
se_mu_3 <- standard_errors[1:3]
se_lambda_3 <- matrix(standard_errors[4:12], nrow = 3, ncol = 3, byrow = TRUE)
se_sigma_3 <- matrix(standard_errors[13:21], nrow = 3, ncol = 3, byrow = TRUE)


## checking if OU fits well

err_3 <- matrix(nrow = 259, ncol = 3)

for (i in 1:259) {
  
  err_3[i,] <- c(solve(q_sigma_3) %*% (diff(Z_t_3)[i,] - q_lambda_3 %*% (q_mu_3 - Z_t_3[i,])))
  
}
par(mfrow = c(3,1))

hist(err_3[,1], main = "First component", xlab = "")
hist(err_3[,2], main = "Second component", xlab = "")
hist(err_3[,3], main = "Third component", xlab = "")

par(mfrow = c(1,1))

## base curves with eigen values

eigen(A_3)

sig_3 <- q_sigma_3 %*% t(q_sigma_3)

eigens_3 <- eigen(sig_3)

eigens_3

h_1 <-  sapply(x, function(y) (c(1,1,1) %*% expm(y * A_3 )) %*% eigens_3$vectors[,1])
h_2 <-  sapply(x, function(y) (c(1,1,1) %*% expm(y * A_3 )) %*% eigens_3$vectors[,2])
h_3 <-  sapply(x, function(y) (c(1,1,1) %*% expm(y * A_3 )) %*% eigens_3$vectors[,3])

plot(x*365, h_1, type = "l", col = "blue", lwd = 2, ylab = "Values", xlab = "Days until maturuty",ylim = c(-3,1))
lines(x*365, h_2, type = "l", col = "red", lwd = 2)
lines(x*365, h_3, type = "l", col = "green", lwd = 2)
legend("topright", legend = c("h_1", "h_2","h_3"), col = c("blue", "red","green"), lwd = 2)

## 5 dim ----

## Loading estimated A and Z_t for 1 dim and plotting Z_t

A_5 <- read.csv("A_5.csv", header = FALSE) |> unname() |> as.matrix()

Z_t_5 <- read.csv("Z_t_5.csv", header = FALSE) |> unname() |> as.matrix()

matplot(ttm$date,Z_t_5, type = "l", lty = 1, col = 1:ncol(Z_t_5), xlab = "Time", ylab = "Values", lwd = 2)

### selection of one specific year

Z_t_5 <- Z_t_5[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                 as.Date(settlement$date) < as.Date("2023-01-01"),]

matplot(as.Date(settlement$date[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                                  as.Date(settlement$date) < as.Date("2023-01-01")]),Z_t_5, type = "l", lty = 1, col = 1:ncol(Z_t_5), xlab = "Time", ylab = "Values", lwd = 2)

## base curves and plotting

g_1 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% c(1,0,0,0,0))
g_2 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% c(0,1,0,0,0))
g_3 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% c(0,0,1,0,0))
g_4 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% c(0,0,0,1,0))
g_5 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% c(0,0,0,0,1))

par(mfrow = c(1,1))

plot(x*365, g_1, type = "l", col = "blue", lwd = 2, ylab = "Values", xlab = "Days until maturity",ylim = c(0.4, 2.5))
lines(x*365, g_2, type = "l", col = "red", lwd = 2)
lines(x*365, g_3, type = "l", col = "green", lwd = 2)
lines(x*365, g_4, type = "l", col = "orange", lwd = 2)
lines(x*365, g_5, type = "l", col = "black", lwd = 2)


legend("topright", legend = c("g_1", "g_2","g_3","g_4","g_5"), col = c("blue", "red","green", "orange", "black"), lwd = 2)

## mu, mean reversion and sigma estimation for Z_t as an OU process

delta_t <- 1
X <- Z_t_5

log_likelihood <- function(params, X, delta_t) {
  mu <- params[1:5]
  A <- matrix(params[6:30], nrow = 5,ncol = 5, byrow = T)
  Simga <- matrix(params[31:55], 5, 5, byrow = T)
 
  Sigma <- Simga %*% t(Simga)
  
  n <- nrow(X)
  logL <- 0
  
  for (i in 2:n) {
    mu_t <- X[i-1, ] + A %*% (mu - X[i-1, ]) * delta_t
    Sigma_t <- Sigma * delta_t
    
    logL <- logL + dmvnorm(X[i, ], mean = mu_t, sigma = Sigma_t, log = TRUE)
  }
  
  return(-logL) # Negative log-likelihood
}


# Initial parameter guesses
initial_params <- c(colMeans(Z_t_5), rep(0,25), c(cov(Z_t_5)))

# Use optim to maximize the log-likelihood
result_5 <- optim(initial_params, log_likelihood, X = X, delta_t = delta_t, method = "BFGS", hessian = TRUE)

q_sigma_5 <- matrix(result_5$par[31:55], nrow = 5,ncol = 5, byrow = T)
q_lambda_5 <- matrix(result_5$par[6:30], nrow = 5,ncol = 5, byrow = T)
q_mu_5 <- result_5$par[1:5]

# Compute the standard errors from the Hessian
hessian_inv <- solve(result_5$hessian)
standard_errors <- sqrt(diag(hessian_inv))

# Extract standard errors for each parameter
se_mu_5 <- standard_errors[1:5]
se_lambda_5 <- matrix(standard_errors[6:30], nrow = 5, ncol = 5, byrow = TRUE)
se_sigma_5 <- matrix(standard_errors[31:55], nrow = 5, ncol = 5, byrow = TRUE)



## checking if OU fits well

err_5 <- matrix(nrow = 259, ncol = 5)

for (i in 1:259) {
  
  err_5[i,] <- c(solve(q_sigma_5) %*% (diff(Z_t_5)[i,] - q_lambda_5 %*% (q_mu_5 - Z_t_5[i,])))
  
}

layout_matrix <- matrix(c(1, 2, 3, 
                          4, 0, 5), 
                        nrow = 2, byrow = TRUE)

# Set up the layout
layout(layout_matrix)

hist(err_5[,1], main = "First component", xlab = "")
hist(err_5[,2], main = "Second component", xlab = "")
hist(err_5[,3], main = "Third component", xlab = "")
hist(err_5[,4], main = "Fourth component", xlab = "")
hist(err_5[,5], main = "Fifth component", xlab = "")

par(mfrow = c(1,1))

## base cureves and eigens

eigen(A_5) # with 5 dim we have imaginary eigenvalues

sig_5 <- q_sigma_5 %*% t(q_sigma_5)

eigens_5 <- eigen(sig_5)

eigens_5

h_1 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% eigens_5$vectors[,1])
h_2 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% eigens_5$vectors[,2])
h_3 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% eigens_5$vectors[,3])
h_4 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% eigens_5$vectors[,4])
h_5 <-  sapply(x, function(y) (c(1,1,1,1,1) %*% expm(y * A_5 )) %*% eigens_5$vectors[,5])

plot(x*365, h_1, type = "l", col = "blue", lwd = 2, ylab = "Values", xlab = "Days until maturuty",ylim = c(-2,3))
lines(x*365, h_2, type = "l", col = "red", lwd = 2)
lines(x*365, h_3, type = "l", col = "green", lwd = 2)
lines(x*365, h_4, type = "l", col = "orange", lwd = 2)
lines(x*365, h_5, type = "l", col = "black", lwd = 2)
legend("topright", legend = c("h_1", "h_2","h_3","h_4","h_5"), col = c("blue", "red","green", "orange","black"), lwd = 2)

## RMSE ----

# 1 dim

f_t <- function(x, Z) c_t + expm(x * A_1 ) %*% Z
Z_t_1 <- read.csv("Z_t_1.csv", header = FALSE) |> unname() |> as.matrix()

err_est_1 <- c()

for (i in 1:dim(time)[1]) {  
  for (j in 1:dim(time)[2]) {
    if(!is.na(time[i,j])){ 
      print(i)
      zeit <- time[i,j] 
      err_est_1 <- c(err_est_1,(p[i,j] - f_t(zeit, Z_t_1[i,]))^2)}
  }
}

sqrt(mean(err_est_1))
mean(sqrt(err_est_1))

# 2 dim

f_t <- function(x, Z) c_t + c(1,1) %*% expm(x * A_2 ) %*% Z
Z_t_2 <- read.csv("Z_t_2.csv", header = FALSE) |> unname() |> as.matrix()

err_est_2 <- c()

for (i in 1:dim(time)[1]) {  
  for (j in 1:dim(time)[2]) {
    if(!is.na(time[i,j])){ 
      print(i)
      zeit <- time[i,j] 
      err_est_2 <- c(err_est_2,(p[i,j] - f_t(zeit, Z_t_2[i,]))^2)}
  }
}

sqrt(mean(err_est_2))
mean(sqrt(err_est_2))

# 3 dim

f_t <- function(x, Z) c_t + c(1,1,1) %*% expm(x * A_3 ) %*% Z
Z_t_3 <- read.csv("Z_t_3.csv", header = FALSE) |> unname() |> as.matrix()

err_est_3 <- c()

for (i in 1:dim(time)[1]) {  
  for (j in 1:dim(time)[2]) {
    if(!is.na(time[i,j])){ 
      print(i)
      zeit <- time[i,j] 
      err_est_3 <- c(err_est_3,(p[i,j] - f_t(zeit, Z_t_3[i,]))^2)}
  }
}

sqrt(mean(err_est_3))
mean(sqrt(err_est_3))

# 5 dim

f_t <- function(x, Z) c_t + c(1,1,1,1,1) %*% expm(x * A_5 ) %*% Z
Z_t_5 <- read.csv("Z_t_5.csv", header = FALSE) |> unname() |> as.matrix()

err_est_5 <- c()

for (i in 1:dim(time)[1]) {  
  for (j in 1:dim(time)[2]) {
    if(!is.na(time[i,j])){ 
      print(i)
      zeit <- time[i,j] 
      err_est_5 <- c(err_est_5,(p[i,j] - f_t(zeit, Z_t_5[i,]))^2)}
  }
}

sqrt(mean(err_est_5))
mean(sqrt(err_est_5))

## Comparison true price day to estimated day term structure in 
## saving working environment----

#save.image(file='yoursession.RData') # To not need to rerun everything always 

## making plot prediction vs actul term structure ----

row.sample <- c(8000)

dates.of.plot <- settlement[row.sample,1]

termstructures.p <- settlement[row.sample,-1] |> as.matrix() |> unname()

termstructures.t <- ttm[row.sample,-1] |> as.matrix() |> unname()

ordering <- order(c(termstructures.t[1,] |> na.omit()), decreasing = FALSE)

# Plot the initial term structure
plot(c(termstructures.t[1,] |> na.omit())[ordering], c(termstructures.p[1,] |> na.omit())[ordering],
     col = 1, type = "l",
     xlab = "Days until maturity", ylab = "Settlement price", lwd = 2, ylim = c(73,110))

points(c(termstructures.t[1,] |> na.omit())[ordering], c(termstructures.p[1,] |> na.omit())[ordering],
       col = 1, pch = 16)

# Calculate the zeiten and z values
zeiten <- c(termstructures.t[1,] |> na.omit())[ordering] / 365
z_1 <- Z_t_1[8000]
z_2 <- Z_t_2[8000,]
z_3 <- Z_t_3[8000,]
z_5 <- Z_t_5[8000,]

# Define the functions for f_t
f_t_1 <- function(x) c_t + exp(x * A_1) %*% z_1
f_t_2 <- function(x) c_t + c(1,1) %*% expm(x * A_2) %*% z_2
f_t_3 <- function(x) c_t + c(1,1,1) %*% expm(x * A_3) %*% z_3
f_t_5 <- function(x) c_t + c(1,1,1,1,1) %*% expm(x * A_5) %*% z_5

# Apply the functions
f_t_1 <- sapply(zeiten, f_t_1)
f_t_2 <- sapply(zeiten, f_t_2)
f_t_3 <- sapply(zeiten, f_t_3)
f_t_5 <- sapply(zeiten, f_t_5)

# Plot the lines and points
lines(zeiten * 365, f_t_1, col = 2, lwd = 2)
points(zeiten * 365, f_t_1, col = 2, pch = 16)
lines(zeiten * 365, f_t_2, col = 3, lwd = 2)
points(zeiten * 365, f_t_2, col = 3, pch = 16)
lines(zeiten * 365, f_t_3, col = 4, lwd = 2)
points(zeiten * 365, f_t_3, col = 4, pch = 16)
lines(zeiten * 365, f_t_5, col = 5, lwd = 2)
points(zeiten * 365, f_t_5, col = 5, pch = 16)

# Add the legend
legend("topright", legend = c("2013-11-26", "f_t_1", "f_t_2", "f_t_3", "f_t_5"), 
       col = c(1, 2, 3, 4, 5), pch = c(16, 16, 16, 16, 16), lwd = 2)

## testing normality ----
 
Z_t_1 <- Z_t_1[as.Date(settlement$date) >= as.Date(as.Date("2022-01-01")) &
                 as.Date(settlement$date) < as.Date("2023-01-01"),] |> as.matrix()

err1 <- 1/q_sigma_1 * (diff(Z_t_1) - q_lambda_1 * (q_mu_1 - Z_t_1[1:259]))

err_2

err_3

err_5

shapiro.test(c(err1)) 

mshapiro.test(t(err_2)) 
mshapiro.test(t(err_3)) 
mshapiro.test(t(err_5)) 

