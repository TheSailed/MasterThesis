
## Setting working directory ## ----

# Here one has to set the working directory to the corresponding directory where the rds files are stored

## Importing rds data ## ----

settlement <- readRDS("settlement.rds")
open <- readRDS("open.rds")
high <- readRDS("high.rds")
low <- readRDS("low.rds")
ex <- readRDS("ex.rds")
ttm <- readRDS("ttm.rds")
ttms <- readRDS("ttms.rds") 
prices <- readRDS("prices.rds")


## Seed for repeatability ## ----

set.seed(1)

## Function to create sample to be used for A and Z_t estimation ## ----

sampler <- function(x){
  
    K <- max(apply(x[,2:dim(x)[2]], 1, function(y) sum(!is.na(y)))) # max contracts ever active trugh sample

    entries <- apply(x[,2:dim(x)[2]],1, function(y) which(!is.na(y))) # which positions are not na

    entries <- lapply(entries , function(y){
      s <- length(y |> as.vector()) # sample length
      if(floor(K/s) != K/s){ # if s is no dividor of s than fill ending u
        fulls <- c(replicate(floor(K/s),sample(y |> as.vector(), s)))
        partial <- sample(y |> as.vector(), K - floor(K/s)*s)
        rowsample <- c(fulls,partial)
      }else{ # s is dividor thus dont fill ip
        rowsample <- c(replicate(floor(K/s),sample(y |> as.vector(), s)))
      }
    })

    entries <- do.call("rbind", entries) |>  as.data.frame() # bind the entries in the dataframe together

    return(entries)

}


## Test and sample set split ## ----

## We used all available data up until the 31.12.2023.

bools <- as.Date(settlement$date) < as.Date("2024-01-01")

Test_settlement <- settlement[!bools,]
Train_settlement <- settlement[bools,]

Test_ttm <- ttm[!bools,]
Train_ttm <- ttm[bools,]

rm(ex,high, low, settlement, open, ttm, bools)

## Data creation ## ----

entries <- sampler(Train_settlement)

prices <- data.frame()
ttms <- data.frame()


for (i in 1:dim(entries)[1]) {
  prices <- rbind(prices, Train_settlement[i, (1 + entries[i,] |> as.vector() |> unlist())] |> unlist() |> as.vector())
  ttms  <- rbind(ttms, Train_ttm[i, (1 + entries[i,] |> as.vector() |> unlist())] |> unlist() |> as.vector())
}

#saveRDS(ttms, file = "ttms.rds") # if one wants to work with a different seed
#saveRDS(prices, file = "prices.rds")

rm(i)

## CSV saving ## ----

c_t <- mean(Train_settlement[,-1] |> as.matrix(), na.rm = T)

prices_without_mean <- prices - c_t

ttms <- ttms/365

ttms <- ttms |> as.data.frame()
prices<- prices |>as.data.frame()
prices_without_mean <- prices_without_mean |> as.data.frame()

colnames(ttms) <- NULL
colnames(prices) <- NULL
colnames(prices_without_mean) <- NULL

rm(Test_settlement,Train_settlement,Train_ttm, Test_ttm,c_t)

# setwd() # where one wants output saved

write.csv(prices, "Prices.csv", row.names = F)
write.csv(prices_without_mean, "Prices(without_mean).csv", row.names = F)
write.csv(ttms, "Ttm.csv", row.names = F)

